<?php
require "auth.php";
require "../config/db.php";

/* ===================== FILTERS ===================== */
$search   = $_GET["search"]   ?? "";
$district = $_GET["district"] ?? "";
$page     = isset($_GET["page"]) ? max(1, intval($_GET["page"])) : 1;

$limit  = 5;
$offset = ($page - 1) * $limit;

/* WHERE conditions */
$where  = [];
$params = [];
$types  = "";

if ($search !== "") {
    $where[]  = "l.name LIKE ?";
    $params[] = "%$search%";
    $types   .= "s";
}

if ($district !== "") {
    $where[]  = "l.district = ?";
    $params[] = $district;
    $types   .= "s";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

/* ===================== TOTAL ROWS ===================== */
$countSql = "
    SELECT COUNT(DISTINCT l.location_id) AS total
    FROM locations l
    $whereSQL
";

$stmt = $conn->prepare($countSql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$totalRows  = $stmt->get_result()->fetch_assoc()["total"];
$totalPages = max(1, ceil($totalRows / $limit));

/* ===================== FETCH LOCATIONS ===================== */
$sql = "
    SELECT 
        l.location_id,
        l.name,
        l.district,
        GROUP_CONCAT(c.name SEPARATOR ', ') AS categories
    FROM locations l
    LEFT JOIN location_categories lc ON l.location_id = lc.location_id
    LEFT JOIN categories c ON lc.category_id = c.category_id
    $whereSQL
    GROUP BY l.location_id
    ORDER BY l.created_at DESC
    LIMIT $limit OFFSET $offset
";

$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$locations = $stmt->get_result();

/* ===================== DISTRICTS ===================== */
$districts = $conn->query(
    "SELECT DISTINCT district FROM locations ORDER BY district"
);

require "partials/header.php";
require "partials/sidebar.php";
?>

<!-- PAGE-SPECIFIC STYLES -->
<style>
.main {
    flex: 1;
    padding: 32px;
}

/* Header */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* Add button */
.btn-add {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 18px;
    background: #2f4f4f;
    color: white;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 600;
}

.btn-add:hover {
    background: #3b6464;
}

/* Filters */
.filters {
    display: grid;
    grid-template-columns: 1fr 200px auto;
    gap: 12px;
    margin: 24px 0;
}

.filters input,
.filters select {
    padding: 12px 14px;
    border-radius: 10px;
    border: 1.5px solid #9aa5a5;
    background: #eef1f1;
}

.filters button {
    padding: 12px 18px;
    border-radius: 10px;
    background: #2f4f4f;
    color: white;
    border: none;
    cursor: pointer;
}

/* Card */
.card {
    background: white;
    border-radius: 20px;
    padding: 26px;
    box-shadow: 0 14px 35px rgba(0,0,0,0.10);
}

/* Grid table */
.grid-row {
    display: grid;
    grid-template-columns: 2fr 1.5fr 3fr 1.5fr;
    align-items: center;
    padding: 16px 0;
}

.grid-row + .grid-row {
    border-top: 2px solid #9aa5a5;
}

.header-row {
    font-weight: 700;
    color: #333;
    background: #e6ebeb;
    padding: 14px 0;
    border-radius: 12px;
}

/* Actions */
.actions {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.actions a {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border-radius: 8px;
    text-decoration: none;
    color: white;
    font-size: 13px;
}

.edit { background: #2f4f4f; }
.delete { background: #c0392b; }

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    margin-top: 28px;
}

.pagination a {
    padding: 8px 14px;
    margin: 0 4px;
    border-radius: 8px;
    background: #e6eaea;
    color: #333;
    text-decoration: none;
}

.pagination a.active {
    background: #2f4f4f;
    color: white;
}
</style>

<div class="main">

    <div class="header">
        <h1>Manage Heritage Locations</h1>
        <a href="add_location.php" class="btn-add">
            <i class="fa fa-plus"></i> Add Location
        </a>
    </div>

    <!-- FILTER BAR -->
    <form class="filters" method="GET">
        <input type="text"
               name="search"
               placeholder="Search by name"
               value="<?= htmlspecialchars($search) ?>">

        <select name="district">
            <option value="">All Districts</option>
            <?php while($d = $districts->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($d["district"]) ?>"
                    <?= $district === $d["district"] ? "selected" : "" ?>>
                    <?= htmlspecialchars($d["district"]) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Filter</button>
    </form>

    <!-- GRID TABLE -->
    <div class="card">

        <div class="grid-row header-row">
            <div>Name</div>
            <div>District</div>
            <div>Categories</div>
            <div style="text-align:right;">Actions</div>
        </div>

        <?php if ($locations->num_rows === 0): ?>
            <div class="grid-row">
                <div>No locations found.</div>
                <div></div><div></div><div></div>
            </div>
        <?php endif; ?>

        <?php while($row = $locations->fetch_assoc()): ?>
            <div class="grid-row">
                <div><?= htmlspecialchars($row["name"]) ?></div>
                <div><?= htmlspecialchars($row["district"]) ?></div>
                <div><?= htmlspecialchars($row["categories"]) ?></div>
                <div class="actions">
                    <a class="edit"
                       href="edit_location.php?id=<?= $row["location_id"] ?>">
                        <i class="fa fa-pen"></i> Edit
                    </a>
                    <a class="delete"
                       href="delete_location.php?id=<?= $row["location_id"] ?>"
                       onclick="return confirm('Delete this location?')">
                        <i class="fa fa-trash"></i>
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- PAGINATION -->
    <div class="pagination">
        <?php for($i = 1; $i <= $totalPages; $i++): ?>
            <a class="<?= $i == $page ? 'active' : '' ?>"
               href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&district=<?= urlencode($district) ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>

</div>

<?php require "partials/footer.php"; ?>

