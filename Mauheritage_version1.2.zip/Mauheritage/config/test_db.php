<?php
include("C:\wamp64\www\Mauheritage\config\db.php");
echo "Database connection successful";
?>
