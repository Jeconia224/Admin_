<?php
require "../config/db.php";

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    echo json_encode(["error" => "Missing or invalid location id"]);
    exit;
}

$location_id = (int) $_GET["id"];

$sql = "
SELECT 
    l.location_id,
    l.name,
    l.description,
    l.district,
    l.latitude,
    l.longitude,
    l.image,
    l.created_at,
    GROUP_CONCAT(c.name SEPARATOR ', ') AS categories
FROM locations l
LEFT JOIN location_categories lc 
    ON l.location_id = lc.location_id
LEFT JOIN categories c 
    ON lc.category_id = c.category_id
WHERE l.location_id = ?
GROUP BY l.location_id
LIMIT 1
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $location_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["error" => "Location not found"]);
    exit;
}

echo json_encode(
    $result->fetch_assoc(),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);

