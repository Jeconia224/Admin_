﻿using Microsoft.EntityFrameworkCore;
using MauritiusMap.Models;

namespace MauritiusMap.Data
{
    public class TreasureMapContext : DbContext
    {
        public TreasureMapContext(DbContextOptions<TreasureMapContext> options) : base(options)
        {
        }

        public DbSet<Login> Logins { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Place> Places { get; set; }
    }
}