﻿using MauritiusMap.Models;
using System.ComponentModel.DataAnnotations;

namespace MauritiusMap.Models
{
    public class Category
    {
        public int id { get; set; }
        [Required]
        public string Name { get; set; }

        // Navigation property
        public ICollection<Place>? Places { get; set; }
    }
}