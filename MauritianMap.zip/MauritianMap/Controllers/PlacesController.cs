﻿using MauritiusMap.Data;
using MauritiusMap.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class PlacesController : ControllerBase
{
    private readonly TreasureMapContext _context;
    public PlacesController(TreasureMapContext context) => _context = context;

    [HttpGet]
    public async Task<ActionResult> Get() =>
        Ok(await _context.Places.Include(p => p.Category).ToListAsync());

    [HttpPost]
    public async Task<ActionResult> Post(Place place)
    {
        _context.Places.Add(place);
        await _context.SaveChangesAsync();
        return Ok(place);
    }
}