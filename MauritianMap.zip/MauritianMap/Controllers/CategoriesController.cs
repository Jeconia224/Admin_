﻿using MauritiusMap.Data;
using MauritiusMap.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class CategoriesController : ControllerBase
{
    private readonly TreasureMapContext _context;
    public CategoriesController(TreasureMapContext context) => _context = context;

    [HttpGet]
    public async Task<ActionResult> Get() => Ok(await _context.Categories.ToListAsync());

    [HttpPost]
    public async Task<ActionResult> Post(Category cat)
    {
        _context.Categories.Add(cat);
        await _context.SaveChangesAsync();
        return Ok(cat);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var cat = await _context.Categories.FindAsync(id);
        if (cat == null) return NotFound();
        _context.Categories.Remove(cat);
        await _context.SaveChangesAsync();
        return Ok();
    }
}