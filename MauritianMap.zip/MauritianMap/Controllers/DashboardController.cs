﻿using MauritiusMap.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class DashboardController : ControllerBase
{
    private readonly TreasureMapContext _context;
    public DashboardController(TreasureMapContext context) => _context = context;

    [HttpGet("stats")]
    public async Task<ActionResult> GetStats()
    {
        var stats = new
        {
            totalCategories = await _context.Categories.CountAsync(),
            totalPlaces = await _context.Places.CountAsync(),
            totalQRCodes = 24, // Dummy value as requested
            recentPlaces = await _context.Places
                .Include(p => p.Category)
                .OrderByDescending(p => p.id)
                .Take(5)
                .Select(p => new { p.Title, CategoryName = p.Category.Name, p.Status })
                .ToListAsync()
        };
        return Ok(stats);
    }
}