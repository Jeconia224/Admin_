<?php
session_start();
require "../config/db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: ../mobile/gallery.php");
    exit();
}

$imageId = intval($_POST["image_id"]);
$userId  = $_SESSION["user_id"];
$role    = $_SESSION["role"];

/* Check ownership */
$sql = "
    SELECT image_path, user_id
    FROM gallery_images
    WHERE image_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $imageId);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    exit();
}

$image = $res->fetch_assoc();

/* Permission check */
if ($role !== "admin" && $image["user_id"] != $userId) {
    exit();
}

/* Delete file */
$file = "../" . $image["image_path"];
if (file_exists($file)) {
    unlink($file);
}

/* Delete record */
$stmt = $conn->prepare("DELETE FROM gallery_images WHERE image_id = ?");
$stmt->bind_param("i", $imageId);
$stmt->execute();

header("Location: ../mobile/gallery.php");
exit();
