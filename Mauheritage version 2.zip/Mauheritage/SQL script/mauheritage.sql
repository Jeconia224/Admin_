-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 24, 2026 at 07:21 AM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mauheritage`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`) VALUES
(1, 'National Heritage', 'Nationally protected heritage sites in Mauritius'),
(2, 'World Heritage', 'UNESCO World Heritage Sites');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `event_date` date DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `gallery_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `caption` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `uploaded_by` int NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`gallery_id`),
  KEY `location_id` (`location_id`),
  KEY `uploaded_by` (`uploaded_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `district` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `name`, `description`, `district`, `latitude`, `longitude`, `image`, `created_at`) VALUES
(1, 'Ganga Talao (Grand Bassin)', 'Ganga Talao, also known as Grand Bassin, is one of the most sacred Hindu pilgrimage sites outside India. Nestled in a serene volcanic crater lake, it is spiritually connected to the River Ganges and attracts thousands of devotees during Maha Shivaratri. Surrounded by lush greenery and majestic statues of Hindu deities, the site represents faith, devotion, and the deep cultural roots of the Hindu community in Mauritius.', 'Savanne', -20.41670000, 57.48330000, 'Assets/Image/ganga_talao.jpg', '2026-01-23 15:24:14'),
(2, 'Le Morne Brabant', 'Le Morne Brabant is a powerful symbol of resistance, freedom, and human dignity. This iconic mountain served as a refuge for enslaved people who escaped bondage during colonial times. Recognised as a UNESCO World Heritage Site, Le Morne stands today as a reminder of the struggles against slavery and the enduring spirit of resilience. Its dramatic cliffs and breathtaking views also make it one of Mauritius’ most striking natural landmarks.', 'Black River', -20.45000000, 57.31670000, 'Assets/Image/le_morne.jpg', '2026-01-20 10:21:37'),
(3, 'Aapravasi Ghat', 'Aapravasi Ghat is a UNESCO World Heritage Site of immense historical importance, marking the arrival of indentured labourers from India after the abolition of slavery. This site played a key role in shaping the multicultural identity of Mauritius. The preserved remains tell the story of migration, hardship, and hope, making Aapravasi Ghat a cornerstone of Mauritian social and cultural history.', 'Port Louis', -20.16100000, 57.49870000, 'Assets/Image/aapravasi_ghat.jpg', '2026-01-20 14:13:23'),
(4, 'Chamarel Seven Coloured Earth', 'The Chamarel Seven Coloured Earth is a unique natural phenomenon featuring rolling sand dunes displaying seven distinct colours. Formed through volcanic activity and mineral composition, the colours never fade despite weather conditions. This rare geological site, set amidst lush vegetation, highlights Mauritius’ volcanic origins and remains one of the island’s most fascinating natural attractions.', 'Black River', -20.44460000, 57.34220000, 'Assets/Image/chamarel.jpg', '2026-01-23 15:37:31'),
(5, 'Trou aux Cerfs', 'Trou aux Cerfs is a dormant volcanic crater located in the heart of Mauritius, offering panoramic views across the island. Surrounded by dense forest and walking paths, it provides visitors with both natural beauty and scientific interest. The crater stands as a testament to the island’s volcanic past and serves as a peaceful spot for reflection and exploration.', 'Plaines Wilhems', -20.31500000, 57.51600000, 'Assets/Image/trou_aux_cerfs.jpg', '2026-01-23 15:51:21'),
(6, 'National History Museum – Mahebourg', 'The National History Museum in Mahebourg preserves and showcases the historical heritage of Mauritius, with a strong focus on the Battle of Grand Port and the colonial past. The museum highlights the island’s cultural evolution and plays an important role in educating visitors about Mauritian history.', 'Grand Port', -20.40660000, 57.70160000, 'Assets/Image/national_history_museum_mahebourg.jpg', '2026-01-23 17:01:42'),
(7, 'Canal Dayot Aqueduct – GRNW', 'The Canal Dayot Aqueduct is a historic engineering structure built during the colonial period to transport water for agricultural and industrial use. Located at Grand River North West, the aqueduct reflects the development of irrigation systems that supported sugar cane cultivation and economic growth in Mauritius.', 'Plaines Wilhems', -20.22580000, 57.47050000, 'Assets/Image/canal_dayot_aqueduct_grnw.jpg', '2026-01-23 17:06:30');

-- --------------------------------------------------------

--
-- Table structure for table `location_categories`
--

DROP TABLE IF EXISTS `location_categories`;
CREATE TABLE IF NOT EXISTS `location_categories` (
  `location_id` int NOT NULL,
  `category_id` int NOT NULL,
  PRIMARY KEY (`location_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location_categories`
--

INSERT INTO `location_categories` (`location_id`, `category_id`) VALUES
(2, 1),
(3, 1),
(2, 2),
(3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `qr_codes`
--

DROP TABLE IF EXISTS `qr_codes`;
CREATE TABLE IF NOT EXISTS `qr_codes` (
  `qr_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `qr_code_url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`qr_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `qr_codes`
--

INSERT INTO `qr_codes` (`qr_id`, `location_id`, `qr_code_url`, `created_at`) VALUES
(1, 1, 'http://localhost/Mauheritage/mobile/details.html?id=1', '2026-01-23 17:17:25'),
(2, 2, 'http://localhost/Mauheritage/mobile/details.html?id=2', '2026-01-23 17:17:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_general_ci DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `profile_pic` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `role`, `created_at`, `profile_pic`) VALUES
(1, 'admin', 'admin@mauheritage.mu', '$2y$10$voslbVwUovD2k3BJ38q4mOibvghSScaRWwuWPewR03j8jOU12XxiO', 'admin', '2026-01-20 12:31:00', NULL),
(3, 'user1', 'user1@example.com', '$2y$10$9qVb/1O2Efo6PvZ8cgL9iubrolS6/Jpb/f6D1PjmeuQRmttNdKT9S', 'user', '2026-01-20 16:18:40', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`) ON DELETE SET NULL;

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `gallery_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `location_categories`
--
ALTER TABLE `location_categories`
  ADD CONSTRAINT `location_categories_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `location_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE;

--
-- Constraints for table `qr_codes`
--
ALTER TABLE `qr_codes`
  ADD CONSTRAINT `qr_codes_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
