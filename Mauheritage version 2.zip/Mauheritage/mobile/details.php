

<?php
// Database connection settings
$host = 'localhost';
$port = '3307'; // MariaDB port
$db   = 'mauheritage';
$user = 'root';
$pass = '';

try {
    // Use mysql driver for MariaDB
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Get location ID from query string
$location_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$location = null;
if ($location_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM locations WHERE location_id = ?");
    $stmt->execute([$location_id]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Location Details</title>
    <style>
        img { max-width: 100%; height: auto; border-radius: 8px; }
        body { font-family: sans-serif; text-align: center; padding: 20px; }
    </style>
</head>
<body>
    <?php if ($location): ?>
        <h1><?php echo htmlspecialchars($location['name']); ?></h1>
        <p><i><?php echo htmlspecialchars($location['district']); ?></i></p>
        
        <!-- Use project-root relative path for images -->
        <img src="/Mauheritage/images/<?php echo htmlspecialchars($location['image']); ?>" alt="Location Image">
        
        <p><?php echo nl2br(htmlspecialchars($location['description'])); ?></p>
    <?php else: ?>
        <p>Location not found.</p>
    <?php endif; ?>
</body>
</html>
