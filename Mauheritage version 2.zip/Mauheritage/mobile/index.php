<?php
session_start();

/* REQUIRE LOGIN */
if (!isset($_SESSION["user_id"])) {
    header("Location: ../admin/login.php");
    exit;
}

$username   = $_SESSION["username"] ?? "";
$profilePic = $_SESSION["profile_pic"] ?? "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>MauHeritage</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet"
 href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
body {
    margin: 0;
    font-family: "Segoe UI", Arial, sans-serif;
    background: url("https://t4.ftcdn.net/jpg/03/16/22/95/360_F_316229543_FXbeM6wA5JxLETB4H7PN8NVwNQ3AwrB2.jpg")
                no-repeat center center/cover;
    height: 100vh;
    color: white;
}
.overlay {
    background: rgba(0, 0, 0, 0.45);
    height: 100%;
    padding: 16px;
    position: relative;
}
.top-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.title {
    font-family: cursive;
    font-size: 28px;
}
.profile {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: white;
    font-size: 14px;
}
.profile img {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid white;
}
.profile i {
    font-size: 36px;
}
.search-box {
    margin: 18px 0;
}
.search-box input {
    width: 100%;
    padding: 12px 16px;
    border-radius: 25px;
    border: none;
    font-size: 14px;
}
.primary-actions {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
}
.primary-actions a {
    flex: 1;
    background: #2f4f4f;
    padding: 16px;
    border-radius: 14px;
    text-align: center;
    text-decoration: none;
    color: white;
    font-size: 14px;
}
.grid {
    background: rgba(0,0,0,0.55);
    border-radius: 18px;
    padding: 14px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 14px;
    text-align: center;
}
.grid a {
    text-decoration: none;
    color: white;
    font-size: 12px;
}
.icon {
    width: 50px;
    height: 50px;
    background: white;
    border-radius: 50%;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 6px;
}
.icon i {
    font-size: 20px;
    color: #2f4f4f;
}
.footer {
    position: absolute;
    bottom: 15px;
    width: 100%;
    text-align: center;
    font-size: 12px;
    opacity: 0.9;
}
</style>
</head>

<body>

<div class="overlay">

<div class="top-bar">
    <div></div>
    <div class="title">MauHeritage</div>

    <a href="../admin/profile.php" class="profile">
        <?php if ($profilePic): ?>
            <img src="<?= htmlspecialchars($profilePic) ?>">
        <?php else: ?>
            <i class="fa-solid fa-user-circle"></i>
        <?php endif; ?>
        <?= htmlspecialchars($username) ?>
    </a>
</div>

<div class="search-box">
<input id="searchInput"
       placeholder="Search heritage sites..."
       onkeydown="handleSearch(event)">
</div>

<div class="primary-actions">
    <a href="map.php"><i class="fa-solid fa-map-location-dot"></i> Explore Map</a>
    <a href="scan.html"><i class="fa-solid fa-qrcode"></i> Scan QR</a>
</div>

<div class="grid">

<a href="national.html"><div class="icon"><i class="fa-solid fa-landmark"></i></div>National<br>Heritage</a>
<a href="world.html"><div class="icon"><i class="fa-solid fa-globe"></i></div>World<br>Heritage</a>
<a href="history.html"><div class="icon"><i class="fa-solid fa-book-open"></i></div>History</a>
<a href="events.html"><div class="icon"><i class="fa-solid fa-calendar-days"></i></div>Events</a>
<a href="treasuremap.php"><div class="icon"><i class="fa-solid fa-gem"></i></div>    Treasure<br>Hunt
</a><a href="gallery.php"><div class="icon"><i class="fa-solid fa-images"></i></div>Gallery</a>
<a href="virtual.html"><div class="icon"><i class="fa-solid fa-vr-cardboard"></i></div>Virtual</a>

</div>

<div class="footer">National Heritage Fund</div>

</div>

<script>
function handleSearch(e){
    if(e.key==="Enter"){
        const q = document.getElementById("searchInput").value.trim();
        if(q.length < 3){
            alert("Please enter at least 3 characters");
            return;
        }
        window.location.href = "map.php?q=" + encodeURIComponent(q);
    }
}
</script>

</body>
</html>


