<?php
session_start();
// Ensure user is logged in as per your app logic
if (!isset($_SESSION["user_id"])) {
    header("Location: ../admin/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MauHeritage Treasure Hunt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { margin: 0; font-family: "Segoe UI", sans-serif; background: #000; color: white; }
        .top-bar { background: rgba(47,79,79,0.95); padding: 15px; text-align: center; position: fixed; width: 100%; z-index: 1000; display: flex; justify-content: space-between; align-items: center; box-sizing: border-box;}
        #map { height: 100vh; width: 100%; }
        .routing-panel { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); z-index: 1000; background: rgba(47,79,79,0.9); padding: 10px; border-radius: 15px; width: 90%; max-width: 400px; text-align: center; }
    </style>
</head>
<body>

<div class="top-bar">
    <a href="index.php" style="color:white;"><i class="fa-solid fa-arrow-left"></i></a>
    <div style="font-family: 'Brush Script MT', cursive; font-size: 24px;">Treasure Map</div>
    <div></div>
</div>

<div id="map">
    
</div>

<div class="routing-panel" id="status-panel">
    <p id="instruction">Select a site on the map to mark as Treasure!</p>
</div>

<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>

<script>
// Initialize map and variables
const map = L.map('map', { zoomControl: false }).setView([-20.3484, 57.5522], 10);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

let userLocation = null;
let targetTreasure = null; // To store current treasure lat/lng
let routingControl = null;
let hasFoundTreasure = false; // Prevent multiple alerts

// Add this to your script section in treasuremap.php

// 1. Listen for clicks on the map itself
map.on('click', function(e) {
    const clickedLat = e.latlng.lat;
    const clickedLng = e.latlng.lng;
    const customName = "Custom Treasure Point";

    // 2. Ask for confirmation or just start the hunt
    if (confirm("Set this specific spot as your treasure goal?")) {
        // Clear old treasure marker if one exists
        if (window.customTreasureMarker) {
            map.removeLayer(window.customTreasureMarker);
        }

        // 3. Place a visual marker at the clicked spot
        window.customTreasureMarker = L.marker([clickedLat, clickedLng], {
            icon: L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-gold.png',
                shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41]
            })
        }).addTo(map).bindPopup("<b> 🪙Treasure</b>").openPopup();

        // 4. Start the existing hunt logic with these new coordinates
        startHunt(clickedLat, clickedLng, customName);
    }
});

// 1. DISTANCE MONITORING
navigator.geolocation.watchPosition(pos => {
    userLocation = L.latLng(pos.coords.latitude, pos.coords.longitude);
    
    // Check proximity if a treasure is set
    if (targetTreasure && !hasFoundTreasure) {
        // Calculate distance in meters
        const distance = userLocation.distanceTo(targetTreasure.latLng);
        
        if (distance < 20) { // 20 meters threshold
            triggerWinCondition(targetTreasure.name);
        }
    }
}, err => console.error(err), { enableHighAccuracy: true });

// 2. TRIGGER ALERT
function triggerWinCondition(name) {
    hasFoundTreasure = true;
    
    // Visual feedback
    document.getElementById('instruction').innerHTML = `<b style="color:#FFD700;">TREASURE REACHED!</b>`;
    
    // Play a sound or show a nice alert
    alert(`Congratulations! You have arrived at ${name}. Now, find the QR code to unlock the secret!`);
    
    // Redirect to the scanner to "claim" the treasure
    setTimeout(() => {
        window.location.href = "scan.html";
    }, 2000);
}

// 3. START HUNT LOGIC
function startHunt(destLat, destLng, name) {
    if (!userLocation) {
        alert("Acquiring GPS signal...");
        return;
    }
// Update the instruction text in your treasuremap.php
document.getElementById('instruction').innerHTML = "Click a marker OR any spot on the map to set your Treasure!";
    hasFoundTreasure = false;
    targetTreasure = { latLng: L.latLng(destLat, destLng), name: name };

    if (routingControl) { map.removeControl(routingControl); }

    document.getElementById('instruction').innerHTML = `Navigating to <b>${name}</b>...`;

    routingControl = L.Routing.control({
        waypoints: [userLocation, targetTreasure.latLng],
        lineOptions: {
            styles: [{ color: '#FFD700', weight: 7, opacity: 0.8 }]
        },
        addWaypoints: false
    }).addTo(map);
}

// Load site markers from your API
fetch("../api/locations.php")
    .then(res => res.json())
    .then(data => {
        data.forEach(loc => {
            const marker = L.marker([loc.latitude, loc.longitude]).addTo(map);
            marker.bindPopup(`
                <b>${loc.name}</b><br>
                <button onclick="startHunt(${loc.latitude}, ${loc.longitude}, '${loc.name}')" 
                        style="background:#FFD700; border:none; padding:8px; border-radius:5px; margin-top:10px; cursor:pointer;">
                    💎 Set as Treasure
                </button>
            `);
        });
    });
</script>
</body>
</html>