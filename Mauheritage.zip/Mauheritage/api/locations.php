<?php
require "../config/db.php";

header("Content-Type: application/json; charset=UTF-8");

$sql = "
SELECT 
    l.location_id,
    l.name,
    l.description,
    l.district,
    l.latitude,
    l.longitude,
    l.image,
    l.created_at,
    GROUP_CONCAT(c.name SEPARATOR ', ') AS categories
FROM locations l
LEFT JOIN location_categories lc 
    ON l.location_id = lc.location_id
LEFT JOIN categories c 
    ON lc.category_id = c.category_id
GROUP BY l.location_id
ORDER BY l.name ASC
";

$result = $conn->query($sql);

$locations = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $locations[] = $row;
    }
}

echo json_encode($locations, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
