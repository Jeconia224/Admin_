<?php
header("Content-Type: application/json");
include("../config/db.php");

$sql = "SELECT * FROM locations";
$result = $conn->query($sql);

$locations = [];

while ($row = $result->fetch_assoc()) {
    $locations[] = $row;
}

echo json_encode($locations);
?>
