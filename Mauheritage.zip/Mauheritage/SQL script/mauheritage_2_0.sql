-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 17, 2026 at 03:36 PM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mauheritage 2.0`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password_hash`) VALUES
(1, 'admin', '$2y$10$QeFQZy3d6zF2pC7c0fP7Ne0t0JcZqk0g4xwqF2d2k8uYp7pYzQnKq');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `event_date` date DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `location_id` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `gallery_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caption` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`gallery_id`),
  KEY `location_id` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `district` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`location_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `name`, `category`, `description`, `district`, `latitude`, `longitude`, `image`, `created_at`) VALUES
(1, 'Aapravasi Ghat', 'National Heritage', 'Historic immigration depot and UNESCO World Heritage Site.', 'Port Louis', -20.1609000, 57.5012000, 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Aapravasi_Ghat_Museum%2C_Mauritius_%2841%29.jpg/960px-Aapravasi_Ghat_Museum%2C_Mauritius_%2841%29.jpg', '2026-01-17 03:53:30'),
(2, 'Eureka House', 'National Heritage', '19th-century colonial mansion showcasing Mauritian history.', 'Moka', -20.2210000, 57.4936000, 'https://www.eureka-house.com/images/eureka-colonial-house-mauritius-exterior-view.jpg', '2026-01-17 03:53:30'),
(3, 'SSR Botanical Garden', 'National Heritage', 'Historic botanical garden famous for giant water lilies.', 'Pamplemousses', -20.1047000, 57.5800000, 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Giant_water_lilies.JPG/500px-Giant_water_lilies.JPG', '2026-01-17 03:53:30'),
(4, 'Le Morne Brabant', 'World Heritage', 'UNESCO World Heritage Site symbolising resistance to slavery.', 'Black River', -20.4515000, 57.3277000, 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Le_Morne_Peninsula_in_Mauritius_%2853697779236%29.jpg/960px-Le_Morne_Peninsula_in_Mauritius_%2853697779236%29.jpg', '2026-01-17 03:53:30'),
(5, 'National History Museum', 'History', 'Museum displaying Mauritian colonial and cultural history.', 'Mahebourg', -20.4087000, 57.7004000, 'https://mauritiusmuseums.govmu.org/mauritiusmuseums/wp-content/uploads/2020/11/nationalhistory.jpg', '2026-01-17 03:53:30'),
(6, 'Ganga Talao (Grand Bassin)', 'Intangible Culture', 'Sacred Hindu pilgrimage site and cultural landmark.', 'Savanne', -20.4077000, 57.4847000, 'https://upload.wikimedia.org/wikipedia/commons/6/6c/Ganga_Talao.jpg', '2026-01-17 03:53:30'),
(7, 'Mahashivaratree Festival', 'Events', 'Annual pilgrimage attracting thousands of devotees.', 'Grand Bassin', -20.4077000, 57.4847000, 'https://upload.wikimedia.org/wikipedia/commons/8/8e/Mahashivaratree_Mauritius.jpg', '2026-01-17 03:53:30'),
(8, 'Black River Gorges Trail', 'Trails', 'Popular hiking trail with panoramic views.', 'Black River', -20.4180000, 57.4555000, 'https://upload.wikimedia.org/wikipedia/commons/3/3b/Black_River_Gorges.jpg', '2026-01-17 03:53:30'),
(9, 'Mauritius Photography Gallery', 'Gallery', 'Gallery showcasing Mauritian heritage and landscapes.', 'Port Louis', -20.1609000, 57.5012000, 'https://upload.wikimedia.org/wikipedia/commons/1/1f/Port_Louis_Mauritius.jpg', '2026-01-17 03:53:30'),
(10, 'Aapravasi Ghat Virtual Tour', 'Virtual', '360-degree virtual exploration of Aapravasi Ghat.', 'Port Louis', -20.1609000, 57.5012000, 'https://upload.wikimedia.org/wikipedia/commons/7/7e/Aapravasi_Ghat.jpg', '2026-01-17 03:53:30'),
(11, 'Fort Adelaide (Citadel)', 'National Heritage', 'Historic military fort offering panoramic views of Port Louis.', 'Port Louis', -20.1588000, 57.5045000, 'https://upload.wikimedia.org/wikipedia/commons/6/6f/Fort_Adelaide_Mauritius.jpg', '2026-01-17 10:29:01'),
(12, 'Blue Penny Museum', 'National Heritage', 'Museum housing rare Mauritian stamps and colonial artefacts.', 'Port Louis', -20.1601000, 57.5056000, 'https://upload.wikimedia.org/wikipedia/commons/3/34/Blue_Penny_Museum.jpg', '2026-01-17 10:29:01'),
(13, 'Mahebourg Waterfront', 'National Heritage', 'Historic coastal village linked to early French settlement.', 'Grand Port', -20.4097000, 57.7017000, 'https://upload.wikimedia.org/wikipedia/commons/8/86/Mahebourg_Waterfront.jpg', '2026-01-17 10:29:01'),
(14, 'Martello Tower (La Preneuse)', 'National Heritage', '19th-century coastal defense tower built by the British.', 'Black River', -20.3637000, 57.3595000, 'https://upload.wikimedia.org/wikipedia/commons/9/9b/Martello_Tower_Mauritius.jpg', '2026-01-17 10:29:01'),
(15, 'Château de Labourdonnais', 'National Heritage', 'Restored colonial estate showcasing Mauritian plantation history.', 'Mapou', -20.0887000, 57.6203000, 'https://upload.wikimedia.org/wikipedia/commons/5/5a/Chateau_de_Labourdonnais.jpg', '2026-01-17 10:29:01'),
(16, 'Gouvernement House', 'National Heritage', 'Historic government building from the French colonial period.', 'Port Louis', -20.1612000, 57.5036000, 'https://upload.wikimedia.org/wikipedia/commons/2/24/Government_House_Mauritius.jpg', '2026-01-17 10:29:01'),
(17, 'Jummah Mosque', 'National Heritage', 'One of the oldest mosques in Mauritius reflecting Islamic heritage.', 'Port Louis', -20.1615000, 57.5060000, 'https://upload.wikimedia.org/wikipedia/commons/5/5f/Jummah_Mosque_Mauritius.jpg', '2026-01-17 10:29:01'),
(18, 'St Louis Cathedral', 'National Heritage', 'Roman Catholic cathedral built during the French colonial era.', 'Port Louis', -20.1620000, 57.5032000, 'https://upload.wikimedia.org/wikipedia/commons/0/0b/St_Louis_Cathedral_Mauritius.jpg', '2026-01-17 10:29:01'),
(19, 'Old Supreme Court Building', 'National Heritage', 'Historic judicial building representing colonial architecture.', 'Port Louis', -20.1604000, 57.5041000, 'https://upload.wikimedia.org/wikipedia/commons/7/73/Old_Supreme_Court_Mauritius.jpg', '2026-01-17 10:29:01');

-- --------------------------------------------------------

--
-- Table structure for table `qr_codes`
--

DROP TABLE IF EXISTS `qr_codes`;
CREATE TABLE IF NOT EXISTS `qr_codes` (
  `qr_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `qr_code_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`qr_id`),
  KEY `location_id` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
