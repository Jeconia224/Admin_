<?php
session_start();
require "../config/db.php";

/* If already logged in, redirect */
if (isset($_SESSION["user_id"])) {
    if ($_SESSION["role"] === "admin") {
        header("Location: dashboard.php");
    } else {
        header("Location: ../mobile/index.php");
    }
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    if ($username === "" || $password === "") {
        $error = "Please fill in all fields.";
    } else {

        $stmt = $conn->prepare(
            "SELECT user_id, username, password_hash, role
             FROM users
             WHERE username = ?
             LIMIT 1"
        );

        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {

            if (password_verify($password, $user["password_hash"])) {

                /* ✅ STORE SESSION */
                $_SESSION["user_id"]  = $user["user_id"];
                $_SESSION["username"] = $user["username"];
                $_SESSION["role"]     = $user["role"];

                /* ✅ ROLE BASED REDIRECT */
                if ($user["role"] === "admin") {
                    header("Location: dashboard.php");
                } else {
                    header("Location: ../mobile/index.php");
                }
                exit();
            }
        }

        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | MauHeritage</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet"
 href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
* { box-sizing: border-box; }

body {
    margin: 0;
    height: 100vh;
    background: linear-gradient(160deg, #2f4f4f, #1f3636);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: "Segoe UI", Arial, sans-serif;
}

.card {
    background: white;
    width: 380px;
    padding: 32px;
    border-radius: 20px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.25);
    text-align: center;
}

.card h1 {
    margin: 0;
    font-family: cursive;
    color: #2f4f4f;
}

.card p {
    margin: 6px 0 24px;
    color: #666;
    font-size: 14px;
}

.input-group {
    display: flex;
    align-items: center;
    border: 1px solid #ccc;
    border-radius: 12px;
    padding: 12px 14px;
    margin-bottom: 16px;
}

.input-group i {
    color: #777;
    margin-right: 10px;
}

.input-group input {
    border: none;
    outline: none;
    flex: 1;
    font-size: 14px;
}

button {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 14px;
    background: #2f4f4f;
    color: white;
    font-size: 15px;
    cursor: pointer;
}

button:hover {
    opacity: 0.9;
}

.error {
    background: #ffe6e6;
    color: #a40000;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 16px;
    font-size: 13px;
}

.footer {
    margin-top: 20px;
    font-size: 12px;
    color: #888;
}
</style>
</head>

<body>

<form class="card" method="POST" autocomplete="off">
    <h1>MauHeritage</h1>
    <p>Secure Login</p>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="input-group">
        <i class="fa-solid fa-user"></i>
        <input type="text" name="username" placeholder="Username" required>
    </div>

    <div class="input-group">
        <i class="fa-solid fa-lock"></i>
        <input type="password" name="password" placeholder="Password" required>
    </div>

    <button type="submit">
        <i class="fa-solid fa-right-to-bracket"></i> Login
    </button>

    <div class="footer">
        © National Heritage Fund – Mauritius
    </div>
</form>

</body>
</html>

