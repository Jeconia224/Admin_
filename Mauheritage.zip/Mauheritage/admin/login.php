<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>MauHeritage Admin Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
/* ✅ CRITICAL FIX */
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: "Segoe UI", Arial, sans-serif;
    height: 100vh;
    background: linear-gradient(135deg, #1e3c3c, #2f4f4f);
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Card */
.login-card {
    background: white;
    width: 100%;
    max-width: 360px;
    padding: 32px 28px;
    border-radius: 18px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.25);
    text-align: center;
}

/* Title */
.login-card h1 {
    margin: 0;
    font-size: 26px;
    color: #2f4f4f;
    font-family: cursive;
}

.login-card p {
    margin: 6px 0 26px;
    font-size: 14px;
    color: #666;
}

/* Inputs */
.input-group {
    position: relative;
    width: 100%;
    margin-bottom: 16px;
}

.input-group i {
    position: absolute;
    top: 50%;
    left: 14px;
    transform: translateY(-50%);
    color: #999;
}

.input-group input {
    width: 100%;
    padding: 12px 14px 12px 42px;
    border-radius: 12px;
    border: 1px solid #ccc;
    font-size: 14px;
}

.input-group input:focus {
    outline: none;
    border-color: #2f4f4f;
    box-shadow: 0 0 0 2px rgba(47,79,79,0.15);
}

/* Button */
button {
    width: 100%;
    padding: 12px;
    background: #2f4f4f;
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 15px;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.2s ease, transform 0.1s ease;
}

button:hover {
    background: #244040;
    transform: translateY(-1px);
}

/* Error */
.error {
    background: #ffe5e5;
    color: #b00000;
    padding: 10px;
    border-radius: 10px;
    font-size: 13px;
    margin-bottom: 14px;
}

/* Footer */
.footer {
    margin-top: 20px;
    font-size: 12px;
    color: #999;
}
</style>
</head>

<body>

<div class="login-card">

    <h1>MauHeritage</h1>
    <p>Admin Dashboard Login</p>

    <?php if (!empty($error)): ?>
        <div class="error">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= $error ?>
        </div>
    <?php endif; ?>

    <form method="post">

        <div class="input-group">
            <i class="fa-solid fa-user"></i>
            <input type="text" name="username" placeholder="Username" required>
        </div>

        <div class="input-group">
            <i class="fa-solid fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required>
        </div>

        <button type="submit">
            <i class="fa-solid fa-right-to-bracket"></i> Login
        </button>

    </form>

    <div class="footer">
        © National Heritage Fund – Mauritius
    </div>

</div>

</body>
</html>

