<?php
require "auth.php";
require "../config/db.php";

/* ===================== STATISTICS ===================== */

$total = $conn->query(
    "SELECT COUNT(*) AS c FROM locations"
)->fetch_assoc()["c"];

$national = $conn->query(
    "SELECT COUNT(DISTINCT l.location_id) AS c
     FROM locations l
     JOIN location_categories lc ON l.location_id = lc.location_id
     JOIN categories c ON lc.category_id = c.category_id
     WHERE c.name = 'National Heritage'"
)->fetch_assoc()["c"];

$world = $conn->query(
    "SELECT COUNT(DISTINCT l.location_id) AS c
     FROM locations l
     JOIN location_categories lc ON l.location_id = lc.location_id
     JOIN categories c ON lc.category_id = c.category_id
     WHERE c.name = 'World Heritage'"
)->fetch_assoc()["c"];

$recent = $conn->query(
    "SELECT name, district, created_at
     FROM locations
     ORDER BY created_at DESC
     LIMIT 10"
);

require "partials/header.php";
require "partials/sidebar.php";
?>

<!-- DASHBOARD-SPECIFIC STYLES -->
<style>
.main {
    flex: 1;
    padding: 32px;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header h1 {
    margin: 0;
    font-size: 24px;
}

.logout {
    text-decoration: none;
    color: #2f4f4f;
    font-weight: bold;
}

/* Stats */
.stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 24px;
    margin-top: 32px;
}

.stat-card {
    background: white;
    padding: 26px;
    border-radius: 20px;
    box-shadow: 0 14px 35px rgba(0,0,0,0.10);
    display: flex;
    align-items: center;
    gap: 18px;
}

.stat-icon {
    width: 58px;
    height: 58px;
    border-radius: 16px;
    background: #2f4f4f;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 22px;
}

.stat-info h3 {
    margin: 0;
    font-size: 14px;
    color: #555;
}

.stat-info p {
    margin: 6px 0 0;
    font-size: 30px;
    font-weight: 700;
    color: #2f4f4f;
}

/* Recent table */
.table-card {
    background: white;
    margin-top: 48px;
    padding: 28px;
    border-radius: 22px;
    box-shadow: 0 14px 35px rgba(0,0,0,0.10);
}

.table-card h2 {
    margin-top: 0;
}

table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
}

th, td {
    padding: 16px;
    text-align: left;
    font-size: 14px;
}

th {
    background: #e6ebeb;
    color: #333;
    font-weight: 700;
    border-bottom: 2px solid #9aa5a5;
}

td {
    border-bottom: 1.5px solid #c3caca;
}

tr:last-child td {
    border-bottom: none;
}

tr:hover td {
    background: #f7f9f9;
}
</style>

<div class="main">

    <div class="header">
        <h1>Welcome, <?= htmlspecialchars($_SESSION["username"]) ?></h1>
    </div>

    <div class="stats">

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fa-solid fa-flag"></i>
            </div>
            <div class="stat-info">
                <h3>Total Heritage Sites</h3>
                <p><?= $total ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fa-solid fa-landmark"></i>
            </div>
            <div class="stat-info">
                <h3>National Heritage</h3>
                <p><?= $national ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fa-solid fa-globe"></i>
            </div>
            <div class="stat-info">
                <h3>World Heritage</h3>
                <p><?= $world ?></p>
            </div>
        </div>

    </div>

    <div class="table-card">
        <h2>Recently Added Locations</h2>

        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>District</th>
                    <th>Date Added</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $recent->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row["name"]) ?></td>
                    <td><?= htmlspecialchars($row["district"]) ?></td>
                    <td><?= date("d M Y", strtotime($row["created_at"])) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require "partials/footer.php"; ?>

