<?php
require "auth.php";
include "../config/db.php";

/* Statistics */
$total = $conn->query("SELECT COUNT(*) AS c FROM locations")->fetch_assoc()["c"];
$national = $conn->query(
    "SELECT COUNT(*) AS c FROM locations WHERE category LIKE '%National%'"
)->fetch_assoc()["c"];
$world = $conn->query(
    "SELECT COUNT(*) AS c FROM locations WHERE category LIKE '%World%'"
)->fetch_assoc()["c"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard | MauHeritage</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
* { box-sizing: border-box; }

body {
    margin: 0;
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f4f6f6;
}

/* Layout */
.container {
    display: flex;
    min-height: 100vh;
}

/* Sidebar */
.sidebar {
    width: 240px;
    background: #2f4f4f;
    color: white;
    padding: 20px;
}

.sidebar h2 {
    margin-top: 0;
    font-family: cursive;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 10px 0;
    font-size: 14px;
}

.sidebar a i {
    margin-right: 8px;
}

.sidebar a:hover {
    opacity: 0.8;
}

/* Main */
.main {
    flex: 1;
    padding: 24px;
}

/* Header */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header h1 {
    margin: 0;
    font-size: 22px;
}

.logout {
    text-decoration: none;
    color: #2f4f4f;
    font-weight: bold;
}

/* Cards */
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-top: 24px;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 14px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.card h3 {
    margin: 0;
    font-size: 16px;
    color: #555;
}

.card p {
    margin-top: 10px;
    font-size: 26px;
    font-weight: bold;
    color: #2f4f4f;
}
</style>
</head>

<body>

<div class="container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h2>MauHeritage</h2>

        <a href="dashboard.php">
            <i class="fa-solid fa-chart-line"></i> Dashboard
        </a>

        <a href="view_locations.php">
            <i class="fa-solid fa-location-dot"></i> Manage Locations
        </a>

        <a href="add_location.php">
            <i class="fa-solid fa-plus"></i> Add Location
        </a>

        <a href="logout.php">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
        </a>
    </div>

    <!-- MAIN -->
    <div class="main">

        <div class="header">
            <h1>Welcome, <?= htmlspecialchars($_SESSION["admin_username"]) ?></h1>
            <a href="logout.php" class="logout">Logout</a>
        </div>

        <!-- STATS -->
        <div class="cards">
            <div class="card">
                <h3>Total Heritage Sites</h3>
                <p><?= $total ?></p>
            </div>

            <div class="card">
                <h3>National Heritage</h3>
                <p><?= $national ?></p>
            </div>

            <div class="card">
                <h3>World Heritage</h3>
                <p><?= $world ?></p>
            </div>
        </div>

    </div>
</div>

</body>
</html>
