<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include("../config/db.php");

if (!isset($_GET['id'])) {
    header("Location: view_locations.php");
    exit();
}

$id = $_GET['id'];

// Fetch existing data
$stmt = $conn->prepare("SELECT * FROM locations WHERE location_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$location = $result->fetch_assoc();

if (!$location) {
    echo "Location not found";
    exit();
}

// Update logic
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $category = $_POST['category'];

    $update = $conn->prepare(
        "UPDATE locations 
         SET name = ?, description = ?, latitude = ?, longitude = ?, category = ?
         WHERE location_id = ?"
    );
    $update->bind_param("ssddsi", $name, $description, $latitude, $longitude, $category, $id);

    if ($update->execute()) {
        header("Location: view_locations.php");
        exit();
    } else {
        $error = "Update failed";
    }
}
?>

<h2>Edit Location</h2>

<form method="post">
    <label>Location Name</label><br>
    <input type="text" name="name" value="<?= htmlspecialchars($location['name']); ?>" required><br><br>

    <label>Description</label><br>
    <textarea name="description" rows="4" required><?= htmlspecialchars($location['description']); ?></textarea><br><br>

    <label>Latitude</label><br>
    <input type="number" step="any" name="latitude" value="<?= $location['latitude']; ?>" required><br><br>

    <label>Longitude</label><br>
    <input type="number" step="any" name="longitude" value="<?= $location['longitude']; ?>" required><br><br>

    <label>Category</label><br>
    <input type="text" name="category" value="<?= htmlspecialchars($location['category']); ?>" required><br><br>

    <button type="submit">Update Location</button>
</form>

<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

<br>
<a href="view_locations.php">Cancel</a>
