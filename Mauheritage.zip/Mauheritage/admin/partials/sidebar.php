<div class="sidebar">
    <h2 class="sidebar-title">MauHeritage</h2>

    <nav class="sidebar-menu">
        <a href="dashboard.php"
           class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-chart-line"></i>
            Dashboard
        </a>

        <a href="view_locations.php"
           class="sidebar-link <?= basename($_SERVER['PHP_SELF']) === 'view_locations.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-location-dot"></i>
            Manage Locations
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="logout.php" class="sidebar-link logout">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>
    </div>
</div>

<style>
.sidebar {
    width: 260px;
    background: #2f4f4f;
    color: white;
    padding: 28px 22px;
    display: flex;
    flex-direction: column;
    height: 100vh;
    position: sticky;
    top: 0;
}

.sidebar-title {
    margin: 0 0 36px;
    font-size: 26px;
    font-family: cursive;
}

.sidebar-menu {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.sidebar-link {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 14px 16px;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    font-size: 15px;
}

.sidebar-link:hover {
    background: rgba(255,255,255,0.12);
}

.sidebar-link.active {
    background: white;
    color: #2f4f4f;
    font-weight: 600;
}

.sidebar-footer {
    margin-top: auto;
    padding-top: 20px;
    color: #2f4f4f;
    border-top: 1px solid rgba(255,255,255,0.15);
}

.sidebar-link.logout:hover {
    background: rgba(255,0,0,0.15);
}
</style>

