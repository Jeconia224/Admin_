<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include("../config/db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $category = $_POST['category'];

    $stmt = $conn->prepare(
        "INSERT INTO locations (name, description, latitude, longitude, category)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("ssdds", $name, $description, $latitude, $longitude, $category);

    if ($stmt->execute()) {
        $success = "Location added successfully";
    } else {
        $error = "Error adding location";
    }
}
?>

<h2>Add New Location</h2>

<form method="post">
    <label>Location Name</label><br>
    <input type="text" name="name" required><br><br>

    <label>Description</label><br>
    <textarea name="description" rows="4" required></textarea><br><br>

    <label>Latitude</label><br>
    <input type="number" step="any" name="latitude" required><br><br>

    <label>Longitude</label><br>
    <input type="number" step="any" name="longitude" required><br><br>

    <label>Category</label><br>
    <input type="text" name="category" placeholder="Heritage / Museum / Nature" required><br><br>

    <button type="submit">Save Location</button>
</form>

<?php
if (isset($success)) echo "<p style='color:green;'>$success</p>";
if (isset($error)) echo "<p style='color:red;'>$error</p>";
?>
