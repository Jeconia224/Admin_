<?php
require "auth.php";
require "../config/db.php";

/* ===================== FETCH CATEGORIES ===================== */
$categories = $conn->query(
    "SELECT category_id, name FROM categories ORDER BY name"
);

/* ===================== HANDLE FORM SUBMIT ===================== */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name        = trim($_POST["name"]);
    $district    = trim($_POST["district"]);
    $latitude    = $_POST["latitude"];
    $longitude   = $_POST["longitude"];
    $description = $_POST["description"] ?? "";
    $imageUrl    = $_POST["image"] ?? "";
    $categoriesSelected = $_POST["categories"] ?? [];

    /* Insert location */
    $stmt = $conn->prepare(
        "INSERT INTO locations
         (name, description, district, latitude, longitude, image)
         VALUES (?, ?, ?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "sssdds",
        $name,
        $description,
        $district,
        $latitude,
        $longitude,
        $imageUrl
    );

    $stmt->execute();
    $locationId = $stmt->insert_id;

    /* Insert categories */
    if (!empty($categoriesSelected)) {
        $catStmt = $conn->prepare(
            "INSERT INTO location_categories (location_id, category_id)
             VALUES (?, ?)"
        );

        foreach ($categoriesSelected as $catId) {
            $catStmt->bind_param("ii", $locationId, $catId);
            $catStmt->execute();
        }
    }

    header("Location: view_locations.php");
    exit();
}

require "partials/header.php";
require "partials/sidebar.php";
?>

<!-- PAGE-SPECIFIC STYLES -->
<style>
.main {
    flex: 1;
    padding: 32px;
}

.card {
    background: white;
    max-width: 900px;
    padding: 32px;
    border-radius: 20px;
    box-shadow: 0 14px 35px rgba(0,0,0,0.10);
}

.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 6px;
    color: #333;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 14px 16px;
    border-radius: 12px;
    border: 2px solid #9aa5a5;
    background: #eef1f1;
    font-size: 15px;
}

.form-group textarea {
    resize: vertical;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #2f4f4f;
    box-shadow: 0 0 0 2px rgba(47,79,79,0.15);
}

.grid-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
}

.categories {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 12px;
    margin-top: 10px;
}

.categories label {
    display: flex;
    align-items: center;
    gap: 10px;
    background: #f0f2f2;
    padding: 10px 14px;
    border-radius: 10px;
    border: 1.5px solid #9aa5a5;
    cursor: pointer;
}

button {
    margin-top: 26px;
    padding: 14px 22px;
    border-radius: 14px;
    border: none;
    background: #2f4f4f;
    color: white;
    font-size: 15px;
    cursor: pointer;
}

button:hover {
    background: #3b6464;
}
</style>

<div class="main">

    <div class="card">

        <h2>Add Heritage Location</h2>

        <form method="POST">

            <div class="form-group">
                <label>Location Name</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="4"></textarea>
            </div>

            <div class="form-group">
                <label>District</label>
                <input type="text" name="district" required>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label>Latitude</label>
                    <input type="number" step="any" name="latitude" required>
                </div>

                <div class="form-group">
                    <label>Longitude</label>
                    <input type="number" step="any" name="longitude" required>
                </div>
            </div>

            <div class="form-group">
                <label>Image URL</label>
                <input type="text" name="image"
                       placeholder="https://example.com/image.jpg">
            </div>

            <div class="form-group">
                <label>Categories</label>
                <div class="categories">
                    <?php while ($cat = $categories->fetch_assoc()): ?>
                        <label>
                            <input type="checkbox"
                                   name="categories[]"
                                   value="<?= $cat["category_id"] ?>">
                            <?= htmlspecialchars($cat["name"]) ?>
                        </label>
                    <?php endwhile; ?>
                </div>
            </div>

            <button type="submit">
                <i class="fa-solid fa-plus"></i> Add Location
            </button>

        </form>

    </div>
</div>

<?php require "partials/footer.php"; ?>

