<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include("../config/db.php");

$result = $conn->query("SELECT * FROM locations ORDER BY created_at DESC");
?>

<h2>View Locations</h2>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Category</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['location_id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['category']); ?></td>
            <td><?= $row['latitude']; ?></td>
            <td><?= $row['longitude']; ?></td>
            <td>
                <a href="edit_location.php?id=<?= $row['location_id']; ?>">Edit</a> |
                <a href="delete_location.php?id=<?= $row['location_id']; ?>"
                   onclick="return confirm('Are you sure you want to delete this location?');">
                   Delete
                </a>
            </td>
        </tr>
    <?php } ?>
</table>

<br>
<a href="dashboard.php">Back to Dashboard</a>
