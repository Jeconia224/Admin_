<?php
session_start();

/* User must be logged in */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

/* User must be admin */
if ($_SESSION["role"] !== "admin") {
    header("Location: ../mobile/index.php");
    exit();
}
