<?php
require "auth.php";
require "../config/db.php";

/* ===================== VALIDATE ID ===================== */
if (!isset($_GET["id"])) {
    header("Location: view_locations.php");
    exit();
}

$location_id = intval($_GET["id"]);

/* ===================== FETCH LOCATION ===================== */
$stmt = $conn->prepare(
    "SELECT name, image FROM locations WHERE location_id = ?"
);
$stmt->bind_param("i", $location_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: view_locations.php");
    exit();
}

$location = $result->fetch_assoc();

/* ===================== HANDLE DELETE ===================== */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    /* Delete category relations */
    $conn->query(
        "DELETE FROM location_categories WHERE location_id = $location_id"
    );

    /* Delete image file if exists */
    if (!empty($location["image"])) {
        $filePath = "../" . $location["image"];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }

    /* Delete location */
    $stmt = $conn->prepare(
        "DELETE FROM locations WHERE location_id = ?"
    );
    $stmt->bind_param("i", $location_id);
    $stmt->execute();

    header("Location: view_locations.php");
    exit();
}

require "partials/header.php";
require "partials/sidebar.php";
?>

<!-- PAGE-SPECIFIC STYLES -->
<style>
.main {
    flex: 1;
    padding: 32px;
    display: flex;
    justify-content: center;
    align-items: flex-start;
}

.delete-card {
    background: white;
    max-width: 520px;
    width: 100%;
    padding: 32px;
    border-radius: 20px;
    box-shadow: 0 16px 40px rgba(0,0,0,0.12);
}

.delete-title {
    margin: 0;
    color: #a40000;
    font-size: 24px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.delete-warning {
    margin-top: 18px;
    font-size: 15px;
    color: #444;
}

.location-name {
    margin: 14px 0 0;
    padding: 14px 18px;
    background: #fff4f4;
    border-left: 5px solid #a40000;
    border-radius: 8px;
    font-size: 17px;
    font-weight: 600;
}

.delete-actions {
    margin-top: 30px;
    display: flex;
    gap: 14px;
}

.btn-danger {
    background: #a40000;
    color: white;
    padding: 14px 24px;
    border-radius: 14px;
    border: none;
    font-size: 15px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.btn-danger:hover {
    background: #c00000;
}

.btn-cancel {
    padding: 14px 24px;
    border-radius: 14px;
    background: #e0e0e0;
    color: #333;
    text-decoration: none;
    font-size: 15px;
    display: inline-flex;
    align-items: center;
}

.btn-cancel:hover {
    background: #d0d0d0;
}
</style>

<div class="main">

    <div class="delete-card">

        <h2 class="delete-title">
            <i class="fa-solid fa-triangle-exclamation"></i>
            Delete Location
        </h2>

        <p class="delete-warning">
            This action is <strong>permanent</strong> and cannot be undone.
            Are you sure you want to delete the following location?
        </p>

        <div class="location-name">
            <?= htmlspecialchars($location["name"]) ?>
        </div>

        <form method="POST" class="delete-actions">
            <button type="submit" class="btn-danger">
                <i class="fa-solid fa-trash"></i>
                Yes, Delete
            </button>

            <a href="view_locations.php" class="btn-cancel">
                Cancel
            </a>
        </form>

    </div>

</div>

<?php require "partials/footer.php"; ?>
