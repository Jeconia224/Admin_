let map;

// Create map
map = L.map("map", { zoomControl: false }).setView([-20.3484, 57.5522], 10);

// Fix blank map issue
setTimeout(() => {
    map.invalidateSize();
}, 300);

// OpenStreetMap tiles
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap contributors"
}).addTo(map);

// Zoom controls bottom-right
L.control.zoom({ position: "bottomright" }).addTo(map);

// Marker color by category
function markerColor(category) {
    if (!category) return "blue";
    category = category.toLowerCase();
    if (category.includes("world")) return "orange";
    if (category.includes("potential")) return "violet";
    return "blue"; // national default
}

// Marker icon factory
function icon(color) {
    return L.icon({
        iconUrl:
          "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-" +
          color + ".png",
        shadowUrl:
          "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34]
    });
}

// Load locations from API
fetch("../api/locations.php")
    .then(res => res.json())
    .then(data => {
        data.forEach(loc => {
            const m = L.marker(
                [parseFloat(loc.latitude), parseFloat(loc.longitude)],
                { icon: icon(markerColor(loc.category)) }
            ).addTo(map);

            m.bindPopup(`
                <strong>${loc.name}</strong><br>
                <a href="details.html?id=${loc.location_id}">
                    Visit Site
                </a>
            `);
        });
    });

// Legend (Keys)
const legend = L.control({ position: "bottomright" });
legend.onAdd = function () {
    const div = L.DomUtil.create("div", "legend");
    div.innerHTML = `
        <div><span style="color:orange;">■</span> World Heritage Site</div>
        <div><span style="color:blue;">■</span> National Heritage Site</div>
        <div><span style="color:purple;">■</span> Potential Heritage Site</div>
    `;
    return div;
};
legend.addTo(map);
</script>

</body>
</html>
