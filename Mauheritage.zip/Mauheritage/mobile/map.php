<?php
session_start();

$selectedCategory = $_GET["cat"] ?? "";
$searchQuery = $_GET["q"] ?? "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>MauHeritage Map</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">

<style>
body {
    margin: 0;
    font-family: "Segoe UI", Arial, sans-serif;
    background: #000;
}

/* Top bar */
.top-bar {
    position: fixed;
    top: 0;
    width: 100%;
    background: rgba(47,79,79,0.95);
    color: white;
    padding: 14px;
    text-align: center;
    font-size: 18px;
    z-index: 1000;
}

/* Info card */
.info-card {
    position: fixed;
    top: 60px;
    left: 50%;
    transform: translateX(-50%);
    background: white;
    padding: 8px 14px;
    border-radius: 20px;
    font-size: 13px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.25);
    z-index: 1000;
}

/* Map */
#map {
    position: absolute;
    top: 110px;
    bottom: 0;
    left: 0;
    right: 0;
}

/* Legend */
.legend {
    background: white;
    padding: 8px 12px;
    border-radius: 10px;
    font-size: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.25);
    line-height: 18px;
}
</style>
</head>

<body>

<div class="top-bar">
    <a href="index.php" style="float:left;color:white;text-decoration:none">
        ←
    </a>
    Heritage Map
</div>

<div class="info-card">Tap a marker to explore a heritage site</div>
<div id="map"></div>

<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<script>
const selectedCategory = <?= json_encode($selectedCategory) ?>;
const searchQuery = <?= json_encode($searchQuery) ?>;

/* ================= MAP INIT ================= */
const map = L.map("map", { zoomControl: false })
    .setView([-20.3484, 57.5522], 10);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap contributors"
}).addTo(map);

L.control.zoom({ position: "bottomright" }).addTo(map);

/* ================= ICONS ================= */
function markerColor(categories) {
    if (!categories) return "blue";
    const c = categories.toLowerCase();
    if (c.includes("world")) return "orange";
    return "blue";
}

function icon(color) {
    return L.icon({
        iconUrl:
          "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-" +
          color + ".png",
        shadowUrl:
          "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34]
    });
}

/* ================= CURRENT LOCATION ================= */
if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(pos => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;

        const userIcon = L.icon({
            iconUrl:
              "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png",
            shadowUrl:
              "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34]
        });

        L.marker([lat, lng], { icon: userIcon })
            .addTo(map)
            .bindPopup("<strong>You are here</strong>")
            .openPopup();

        map.setView([lat, lng], 12);
    });
}

/* ================= LOAD LOCATIONS ================= */
fetch("../api/locations.php")
.then(res => res.json())
.then(data => {
    data.forEach(loc => {

        if (selectedCategory &&
            (!loc.categories ||
             !loc.categories.toLowerCase().includes(selectedCategory.toLowerCase())))
            return;

        if (searchQuery &&
            (!loc.name ||
             !loc.name.toLowerCase().includes(searchQuery.toLowerCase())))
            return;

        const marker = L.marker(
            [parseFloat(loc.latitude), parseFloat(loc.longitude)],
            { icon: icon(markerColor(loc.categories)) }
        ).addTo(map);

        marker.bindPopup(`
            <strong>${loc.name}</strong><br>
            ${loc.categories || ""}<br>
            <a href="details.php?id=${loc.location_id}">
                Visit Site
            </a>
        `);
    });
});

/* ================= LEGEND ================= */
const legend = L.control({ position: "bottomright" });
legend.onAdd = function () {
    const div = L.DomUtil.create("div", "legend");
    div.innerHTML = `
        <div><span style="color:orange;">■</span> World Heritage Site</div>
        <div><span style="color:blue;">■</span> National Heritage Site</div>
        <div><span style="color:green;">■</span> Your Location</div>
    `;
    return div;
};
legend.addTo(map);
</script>

</body>
</html>


